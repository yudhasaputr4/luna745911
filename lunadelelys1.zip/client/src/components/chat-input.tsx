import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send } from "lucide-react";
import { MOODS, type MoodType } from "@/lib/mood-config";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onMoodChange: (mood: MoodType) => void;
  isLoading: boolean;
}

export function ChatInput({ onSendMessage, onMoodChange, isLoading }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const [charCount, setCharCount] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isLoading) return;

    onSendMessage(message.trim());
    setMessage("");
    setCharCount(0);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= 500) {
      setMessage(value);
      setCharCount(value.length);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  const handleQuickAction = (action: string) => {
    if (action.startsWith("mood=")) {
      const mood = action.split("=")[1] as MoodType;
      onMoodChange(mood);
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [message]);

  return (
    <div className="border-t border-gray-200 bg-white p-4">
      <form onSubmit={handleSubmit} className="flex items-end space-x-3">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            placeholder="Tulis pesan atau ketik 'mood=bahagia' untuk mengubah mood..."
            value={message}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            className="min-h-[44px] max-h-32 resize-none rounded-2xl pr-12"
            rows={1}
          />
          <div className={`absolute bottom-2 right-12 text-xs ${charCount > 400 ? 'text-red-400' : 'text-gray-400'}`}>
            {charCount}/500
          </div>
        </div>
        
        <Button 
          type="submit" 
          disabled={!message.trim() || isLoading}
          className="rounded-full p-3 h-auto"
        >
          <Send className="w-4 h-4" />
        </Button>
      </form>
      
      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2 mt-3">
        {Object.entries(MOODS).map(([key, mood]) => (
          <Button
            key={key}
            variant="outline"
            size="sm"
            onClick={() => handleQuickAction(`mood=${key}`)}
            className="text-xs rounded-full bg-gray-100 hover:bg-gray-200 border-0"
          >
            {mood.emoji} {mood.name}
          </Button>
        ))}
      </div>
    </div>
  );
}
